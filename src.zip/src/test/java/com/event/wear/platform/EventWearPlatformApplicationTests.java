package com.event.wear.platform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventWearPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
