package com.event.wear.platform.publication.domain.model.queries;

public record GetAllCommentsQuery() {
}
