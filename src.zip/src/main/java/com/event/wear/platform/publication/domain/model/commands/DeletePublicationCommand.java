package com.event.wear.platform.publication.domain.model.commands;

public record DeletePublicationCommand(Long publicationId) {
}
