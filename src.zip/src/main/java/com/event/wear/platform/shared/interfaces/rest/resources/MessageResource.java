package com.event.wear.platform.shared.interfaces.rest.resources;

public class MessageResource {
}
